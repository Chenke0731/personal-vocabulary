# Reviewer-Calibration First Measured Run — Pre-Registration (#653)

> **Corpus status (2026-09-06, #828):** the frozen ICLR 2026 corpus leaks the
> label through PDF layout and is a *harness rehearsal* corpus only. Runs on
> it publish no measurement row and no profile. This plan otherwise stands
> for the ICLR 2027 submission-time corpus.

Registered before the first scored panel dispatches. Changes after the first
dispatch are amendments logged in RUN_NOTES, never silent edits.

## Subject and tier

- **Tier**: `full` (calibration_mode_protocol.md; the only tier that produces
  a measured error profile).
- **Subject**: the `academic-paper-reviewer` calibration panel engine
  (pre-v3.6.2 single-call five-seat + synthesizer semantics), dispatched
  isolated via `scripts/dispatch_calibration_panel.py`.
- **Subject model**: `claude-fable-5-1` (Claude Fable 5.1; updated from
  `claude-fable-5` on 2026-09-06 before any dispatch — a pre-dispatch edit,
  not an amendment), effort `xhigh`, headless `claude -p --bare` with emptied
  tool whitelist (E4 transport recipe), an allowlisted environment and an
  empty `CLAUDE_CONFIG_DIR` (the 2026-09-07 probe showed `--bare` alone still
  delivers the operator's global CLAUDE.md, `language` setting and output
  style to the seats), stream-json capture of every assistant message (a
  continued reply is not truncated to its last message); fresh process per
  call; alias resolution and a contamination probe run before the fleet.

## Gold corpus

- ICLR 2026 (OpenReview, public decisions), n=12: 6 accept-side
  (`Accept (Poster|Spotlight|Oral)` → `accept`), 6 reviewed-and-rejected
  (`reject`). Withdrawn / desk-rejected sit in separate OpenReview venue
  partitions and never enter a pool.
- Selection: seeded deterministic shuffle
  (seed `ars-653-reviewer-calibration-iclr2026-v1`) over the full public
  pools (accepted n=5351, rejected n=8356; sorted-id sha256 pinned in
  `corpus/papers.json`), stratified 6+6, page cap 60, exclusions ledger with
  a closed reason enum. Rule details: `scripts/assemble_calibration_corpus.py`.
- Contamination probe: before freezing, each candidate title was probed on
  the subject model (fresh context) for claimed recall of the actual ICLR
  2026 outcome. Hit rule (pre-registered): `knows_paper=true` AND claimed
  outcome matches gold AND confidence `recall`. Result: 0 hits / 18
  candidates; one candidate reported knowing the paper but not its outcome
  (recorded in README). Probe transcripts retained in the raw evidence area.

## Substrate plan (locked)

- `substrate_plan: primary_only`, locked before the first scored panel, per
  the calibration transport exception's fallback branch: cross-model
  Reviewer-2 is configured-but-unconsented for this run (user decision
  2026-08-07: first execution prioritizes a completed homogeneous attempt;
  the attempt-atomicity rule makes a mid-attempt cross-model failure
  invalidate the whole attempt). Disclosure: the published profile and any
  session disclosure carry the single-family correlated-error caveat and the
  same-family optimism note (protocol § Same-family / rubric-aware judging).
- One `attempt_id` for the whole schedule. A panel abort inside the schedule
  blocks that replicate; recovery is re-dispatch of that replicate under the
  same plan (primary-only has no mixed-substrate hazard). No completed panel
  is ever discarded silently; blocked records are committed.

## Schedule and ensembling

- `runs_per_paper: 3` (protocol budget override; majority-vote decisions on
  the acceptable/reject side, exact-label mode per paper; replicate
  agreement — on side and on exact label — reported as stability. No
  continuous score exists under the categorical seat contract, so nothing is
  averaged.)
- Cards stage once per paper (field analyst; four Reviewer Configuration
  Cards frozen, reused by every replicate). 12 cards calls + 36 panels ×
  (5 seats + 1 synthesis) = 228 subject calls planned.
- Output verification happens only after the dispatching process exits
  (in-flight reads of 0-byte redirect targets are not failures — #652 run
  note); output sweeps include CJK/divider scans for ambient-config leakage.

## Judges (Phase 3.5 severity-risk classification)

- Two judge configurations, two model families (#654 I2):
  `judge-claude-fable-5-1` (Anthropic) and `judge-codex-gpt-6-astra-xhigh`
  (OpenAI, codex CLI, stateless `< /dev/null`, timeout ≥ 600 s, one retry,
  attempt-atomic per item batch; `gpt-6-astra` is the recommended OpenAI
  verifier under the #783 generation-currency policy and is **provisional**
  on the codex transport — the judge row records that status).
- Judges see the seats' weakness text only — never the manuscript, never
  gold labels. Divergent items escalate to maintainer adjudication under
  `adjudication_rubric.md` (criterion_ref required). Judge failure after the
  retry leaves the item to `attempts.blocked_runs` + `partial_published`.

## What publishes

- Per-panel records + raw bundles under `runs/` (write-once).
- `scripts/score_calibration_run.py` metrics JSON (mechanical headline:
  confusion matrix, balanced accuracy, FNR over-harsh, FPR lenient,
  bootstrap 95% CIs seed 653, exact-label agreement, replicate stability;
  AUC NOT REPORTED per protocol Phase 2 — no continuous rubric score;
  Minor/Major sub-matrix NOT ESTIMABLE; per-dimension error NOT COMPUTABLE).
- The Phase 4 Calibration Report (protocol template; Lu 2026 comparison
  table shown — all-binary accept/reject ML-venue gold set qualifies — with
  Lu values as descriptive context, never a benchmark target).
- One `measurement-<date>.json` row under the `heldout-measurement/1.1`
  contract (`suite: reviewer_calibration`, `suite_class: llm_judged`,
  `decision_relevant: true`, `judge_plan.exception: "none"`). 1.1 (the only
  version accepted for new rows since #664) additionally requires a
  `preregistration` record binding this file and `adjudication_rubric.md`
  by SHA-256 to the frozen commit, and a suite-local write-once
  `execution_manifest` with per-call ids, RFC-3339 start/complete
  timestamps, and prompt/output hashes — the dispatcher's `manifest` stage
  emits the manifest; `scripts/build_calibration_measurement_row.py` builds
  the row from the scorer output, the manifest, the judge rows and the
  pre-registered plan + rubric (hash-compared against `frozen_commit`), and
  refuses to write a row the contract checker rejects. Both land with the
  scored run, never after.
